-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 26, 2024 at 11:07 AM
-- Server version: 10.8.4-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `otk_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id_cl` int(10) NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id_cl`, `name`, `address`, `phone_number`) VALUES
(1, 'Камень Глеб Петрвоич', 'ул. Мира, 142', '79285432374'),
(2, 'Щука Ира Сергеевна', 'ул. Краткая, 81', '79054327682'),
(3, 'Розетка Арина Андреевна', 'ул. Грома, 2', '79289873482'),
(4, 'Соболь Кирилл Эдуардович', 'ул. Книги, 75', '79285421742'),
(5, 'Компьютер Михаил Сергеевич', 'пр. Кабеля, 01', '01010101010'),
(6, 'ООО \"ЩукаРыба\"', 'г.Озеро, д.Дно, 28', '8 (   )    -  -'),
(7, 'rKBTYN 123', 'уЛИЦА 12313', '8 (928) 623-72-31'),
(8, 'Раз Два Три', 'Дом 45', '8 (928) 737-27-32'),
(9, 'Клюква Денис Дмитриевич', 'ул. Дом', '8 (908) 123-43-24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id_cl`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id_cl` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
