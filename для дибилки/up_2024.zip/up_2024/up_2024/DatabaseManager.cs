﻿using MySql.Data.MySqlClient;

namespace up_2024 
{
    internal class DatabaseManager
    {
        /// <summary>
        /// Поле данных для соединения с базой данных
        /// </summary>
        MySqlConnection connection = new MySqlConnection
            (
            "server = localhost;" +
            "port = 3306;" +
            "username = root;" +
            "password =;" +
            "database = otk_database" 
            );

        /// <summary>
        /// Метод, который открывает соединение
        /// </summary>
        public void OpenConnection()
        {
            // Проверяем состояние подключения
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();
        }

        /// <summary>
        /// Закрываем соединение
        /// </summary>
        public void CloseConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
        }

        /// <summary>
        /// Свойство, возвращающее открытое соединение с БД
        /// </summary>
        public MySqlConnection GetConnection { get { return connection; } }
    }
}
