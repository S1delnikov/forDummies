﻿namespace up_2024
{
    partial class Authorization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_greetings = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_username = new System.Windows.Forms.TextBox();
            this.textBox_password = new System.Windows.Forms.TextBox();
            this.checkBox_showPassword = new System.Windows.Forms.CheckBox();
            this.button_logIn = new System.Windows.Forms.Button();
            this.linkLabel_OpenRegForm = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // label_greetings
            // 
            this.label_greetings.AutoSize = true;
            this.label_greetings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_greetings.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.label_greetings.Location = new System.Drawing.Point(387, 9);
            this.label_greetings.Name = "label_greetings";
            this.label_greetings.Size = new System.Drawing.Size(188, 20);
            this.label_greetings.TabIndex = 0;
            this.label_greetings.Text = "Здравствуйте, Гость";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(96, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(378, 50);
            this.label2.TabIndex = 1;
            this.label2.Text = "Внимание! Для формирования заказа \r\n             необходима авторизация";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(98, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Пользователь";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(98, 188);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Пароль";
            // 
            // textBox_username
            // 
            this.textBox_username.Location = new System.Drawing.Point(239, 140);
            this.textBox_username.Name = "textBox_username";
            this.textBox_username.Size = new System.Drawing.Size(226, 22);
            this.textBox_username.TabIndex = 4;
            // 
            // textBox_password
            // 
            this.textBox_password.Location = new System.Drawing.Point(239, 185);
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.Size = new System.Drawing.Size(226, 22);
            this.textBox_password.TabIndex = 5;
            // 
            // checkBox_showPassword
            // 
            this.checkBox_showPassword.AutoSize = true;
            this.checkBox_showPassword.Location = new System.Drawing.Point(101, 246);
            this.checkBox_showPassword.Name = "checkBox_showPassword";
            this.checkBox_showPassword.Size = new System.Drawing.Size(159, 20);
            this.checkBox_showPassword.TabIndex = 6;
            this.checkBox_showPassword.Text = "Отображать пароль";
            this.checkBox_showPassword.UseVisualStyleBackColor = true;
            this.checkBox_showPassword.CheckedChanged += new System.EventHandler(this.checkBox_showPassword_CheckedChanged);
            // 
            // button_logIn
            // 
            this.button_logIn.Location = new System.Drawing.Point(346, 276);
            this.button_logIn.Name = "button_logIn";
            this.button_logIn.Size = new System.Drawing.Size(119, 28);
            this.button_logIn.TabIndex = 7;
            this.button_logIn.Text = "Войти";
            this.button_logIn.UseVisualStyleBackColor = true;
            this.button_logIn.Click += new System.EventHandler(this.button_logIn_Click);
            // 
            // linkLabel_OpenRegForm
            // 
            this.linkLabel_OpenRegForm.AutoSize = true;
            this.linkLabel_OpenRegForm.Location = new System.Drawing.Point(12, 316);
            this.linkLabel_OpenRegForm.Name = "linkLabel_OpenRegForm";
            this.linkLabel_OpenRegForm.Size = new System.Drawing.Size(148, 16);
            this.linkLabel_OpenRegForm.TabIndex = 8;
            this.linkLabel_OpenRegForm.TabStop = true;
            this.linkLabel_OpenRegForm.Text = "Регистрация клиента";
            this.linkLabel_OpenRegForm.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_OpenRegForm_LinkClicked);
            // 
            // Authorization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 341);
            this.Controls.Add(this.linkLabel_OpenRegForm);
            this.Controls.Add(this.button_logIn);
            this.Controls.Add(this.checkBox_showPassword);
            this.Controls.Add(this.textBox_password);
            this.Controls.Add(this.textBox_username);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label_greetings);
            this.Name = "Authorization";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_greetings;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_username;
        private System.Windows.Forms.TextBox textBox_password;
        private System.Windows.Forms.CheckBox checkBox_showPassword;
        private System.Windows.Forms.Button button_logIn;
        private System.Windows.Forms.LinkLabel linkLabel_OpenRegForm;
    }
}