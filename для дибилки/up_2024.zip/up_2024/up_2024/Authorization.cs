﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace up_2024
{
    public partial class Authorization : Form
    {
        public Authorization()
        {
            InitializeComponent();

            textBox_password.UseSystemPasswordChar = true;
        }

        /// <summary>
        /// Поле для работы с базой данных
        /// </summary>
        DatabaseManager db = new DatabaseManager();

        /// <summary>
        /// Обработчик события на кнопку "Войти"
        /// </summary>
        private void button_logIn_Click(object sender, EventArgs e)
        {
            string login = textBox_username.Text;
            string password = textBox_password.Text;

            MySqlCommand query = new MySqlCommand("SELECT * FROM employees " +
                "WHERE login=@login AND password=@password", db.GetConnection);

            query.Parameters.Add("@login", MySqlDbType.VarChar).Value = login;
            query.Parameters.Add("@password", MySqlDbType.VarChar).Value = password;

            db.OpenConnection();
            MySqlDataReader reader = query.ExecuteReader();

            if (!reader.HasRows)
            {
                MessageBox.Show("Некорректный логин или пароль", "Ошибка!");
                reader.Close();
                return;
            }
            User user = new User(login, password);
            OrderLog form = new OrderLog(user, this);
            this.Hide();
            form.ShowDialog();
            reader.Close();
            db.CloseConnection();

            textBox_username.Text = string.Empty;
            textBox_password.Text = string.Empty;
        }

        /// <summary>
        /// Обработчик события на ссылку "Регистрация клиента"
        /// </summary>
        private void linkLabel_OpenRegForm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            ClientRegistration clientRegistration = new ClientRegistration(this);
            clientRegistration.Show();
        }

        /// <summary>
        /// Обработчик события изменения отметки чекбокса "Отображать пароль"
        /// </summary>
        private void checkBox_showPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_showPassword.Checked)
                textBox_password.UseSystemPasswordChar = false;
            else
                textBox_password.UseSystemPasswordChar = true;
        }
    }
}
