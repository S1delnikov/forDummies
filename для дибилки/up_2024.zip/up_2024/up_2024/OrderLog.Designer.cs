﻿namespace up_2024
{
    partial class OrderLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_greetings = new System.Windows.Forms.Label();
            this.button_logOut = new System.Windows.Forms.Button();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.groupBox_order = new System.Windows.Forms.GroupBox();
            this.dateTimePicker_orderCreate = new System.Windows.Forms.DateTimePicker();
            this.comboBox_service = new System.Windows.Forms.ComboBox();
            this.comboBox_clients = new System.Windows.Forms.ComboBox();
            this.button_saveOrder = new System.Windows.Forms.Button();
            this.checkBox_Status = new System.Windows.Forms.CheckBox();
            this.textBox_discounte = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_price = new System.Windows.Forms.TextBox();
            this.textBox_orderIndex = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.groupBox_order.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_greetings
            // 
            this.label_greetings.AutoSize = true;
            this.label_greetings.Location = new System.Drawing.Point(19, 13);
            this.label_greetings.Name = "label_greetings";
            this.label_greetings.Size = new System.Drawing.Size(135, 16);
            this.label_greetings.TabIndex = 0;
            this.label_greetings.Text = "Зравствуйте, Гость";
            // 
            // button_logOut
            // 
            this.button_logOut.Location = new System.Drawing.Point(701, 10);
            this.button_logOut.Name = "button_logOut";
            this.button_logOut.Size = new System.Drawing.Size(75, 23);
            this.button_logOut.TabIndex = 1;
            this.button_logOut.Text = "Выйти";
            this.button_logOut.UseVisualStyleBackColor = true;
            this.button_logOut.Click += new System.EventHandler(this.button_logOut_Click);
            // 
            // dataGrid
            // 
            this.dataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(12, 47);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.RowHeadersVisible = false;
            this.dataGrid.RowHeadersWidth = 51;
            this.dataGrid.RowTemplate.Height = 24;
            this.dataGrid.Size = new System.Drawing.Size(776, 262);
            this.dataGrid.TabIndex = 2;
            // 
            // groupBox_order
            // 
            this.groupBox_order.Controls.Add(this.dateTimePicker_orderCreate);
            this.groupBox_order.Controls.Add(this.comboBox_service);
            this.groupBox_order.Controls.Add(this.comboBox_clients);
            this.groupBox_order.Controls.Add(this.button_saveOrder);
            this.groupBox_order.Controls.Add(this.checkBox_Status);
            this.groupBox_order.Controls.Add(this.textBox_discounte);
            this.groupBox_order.Controls.Add(this.label6);
            this.groupBox_order.Controls.Add(this.textBox_price);
            this.groupBox_order.Controls.Add(this.textBox_orderIndex);
            this.groupBox_order.Controls.Add(this.label5);
            this.groupBox_order.Controls.Add(this.label4);
            this.groupBox_order.Controls.Add(this.label3);
            this.groupBox_order.Controls.Add(this.label2);
            this.groupBox_order.Controls.Add(this.label1);
            this.groupBox_order.Location = new System.Drawing.Point(12, 325);
            this.groupBox_order.Name = "groupBox_order";
            this.groupBox_order.Size = new System.Drawing.Size(776, 224);
            this.groupBox_order.TabIndex = 3;
            this.groupBox_order.TabStop = false;
            this.groupBox_order.Text = "Новый заказ";
            // 
            // dateTimePicker_orderCreate
            // 
            this.dateTimePicker_orderCreate.Location = new System.Drawing.Point(180, 63);
            this.dateTimePicker_orderCreate.Name = "dateTimePicker_orderCreate";
            this.dateTimePicker_orderCreate.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker_orderCreate.TabIndex = 13;
            // 
            // comboBox_service
            // 
            this.comboBox_service.FormattingEnabled = true;
            this.comboBox_service.Location = new System.Drawing.Point(180, 135);
            this.comboBox_service.Name = "comboBox_service";
            this.comboBox_service.Size = new System.Drawing.Size(416, 24);
            this.comboBox_service.TabIndex = 12;
            this.comboBox_service.SelectedValueChanged += new System.EventHandler(this.comboBox_service_SelectedValueChanged);
            // 
            // comboBox_clients
            // 
            this.comboBox_clients.FormattingEnabled = true;
            this.comboBox_clients.Location = new System.Drawing.Point(180, 100);
            this.comboBox_clients.Name = "comboBox_clients";
            this.comboBox_clients.Size = new System.Drawing.Size(416, 24);
            this.comboBox_clients.TabIndex = 11;
            // 
            // button_saveOrder
            // 
            this.button_saveOrder.Location = new System.Drawing.Point(608, 26);
            this.button_saveOrder.Name = "button_saveOrder";
            this.button_saveOrder.Size = new System.Drawing.Size(156, 30);
            this.button_saveOrder.TabIndex = 10;
            this.button_saveOrder.Text = "Сохранить заказ";
            this.button_saveOrder.UseVisualStyleBackColor = true;
            this.button_saveOrder.Click += new System.EventHandler(this.button_saveOrder_Click);
            // 
            // checkBox_Status
            // 
            this.checkBox_Status.AutoSize = true;
            this.checkBox_Status.Location = new System.Drawing.Point(608, 67);
            this.checkBox_Status.Name = "checkBox_Status";
            this.checkBox_Status.Size = new System.Drawing.Size(95, 20);
            this.checkBox_Status.TabIndex = 9;
            this.checkBox_Status.Text = "Выполнен";
            this.checkBox_Status.UseVisualStyleBackColor = true;
            // 
            // textBox_discounte
            // 
            this.textBox_discounte.Location = new System.Drawing.Point(496, 171);
            this.textBox_discounte.Name = "textBox_discounte";
            this.textBox_discounte.Size = new System.Drawing.Size(100, 22);
            this.textBox_discounte.TabIndex = 8;
            this.textBox_discounte.Text = "0";
            this.textBox_discounte.TextChanged += new System.EventHandler(this.textBox_discounte_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(346, 174);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 16);
            this.label6.TabIndex = 7;
            this.label6.Text = "с учётом скидки, %:";
            // 
            // textBox_price
            // 
            this.textBox_price.Enabled = false;
            this.textBox_price.Location = new System.Drawing.Point(180, 171);
            this.textBox_price.Name = "textBox_price";
            this.textBox_price.Size = new System.Drawing.Size(100, 22);
            this.textBox_price.TabIndex = 6;
            // 
            // textBox_orderIndex
            // 
            this.textBox_orderIndex.Enabled = false;
            this.textBox_orderIndex.Location = new System.Drawing.Point(180, 30);
            this.textBox_orderIndex.Name = "textBox_orderIndex";
            this.textBox_orderIndex.Size = new System.Drawing.Size(100, 22);
            this.textBox_orderIndex.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Стоимость, руб.:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Услуга:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Клиент:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Дата оформления:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Номер заказа:";
            // 
            // OrderLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 561);
            this.Controls.Add(this.groupBox_order);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.button_logOut);
            this.Controls.Add(this.label_greetings);
            this.Name = "OrderLog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Формирование заказа";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OrderLog_FormClosed);
            this.Load += new System.EventHandler(this.OrderLog_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.groupBox_order.ResumeLayout(false);
            this.groupBox_order.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_greetings;
        private System.Windows.Forms.Button button_logOut;
        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.GroupBox groupBox_order;
        private System.Windows.Forms.DateTimePicker dateTimePicker_orderCreate;
        private System.Windows.Forms.ComboBox comboBox_service;
        private System.Windows.Forms.ComboBox comboBox_clients;
        private System.Windows.Forms.Button button_saveOrder;
        private System.Windows.Forms.CheckBox checkBox_Status;
        private System.Windows.Forms.TextBox textBox_discounte;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_price;
        private System.Windows.Forms.TextBox textBox_orderIndex;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}