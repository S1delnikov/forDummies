﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace up_2024
{
    public partial class OrderLog : Form
    {
        User user;
        DatabaseManager db = new DatabaseManager();
        Authorization authorization;
        float price = 0;
        float discount = 0;

        public OrderLog()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Конструктор формы с параметрами
        /// </summary>
        /// <param name="user">Данные авторизованного пользователя</param>
        /// <param name="authorization">Родительская форма, для возвращения к ней, после закрытия формы OrderLog</param>
        public OrderLog(User user, Authorization authorization)
        {
            InitializeComponent();

            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT id_emp, name, login, password FROM employees " +
                                                "WHERE login=@login", 
                                                db.GetConnection);
            cmd.Parameters.Add("login", MySqlDbType.VarChar).Value = user.Login;
            MySqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            this.user = new User(reader.GetInt32(0), reader.GetString(1), reader.GetString(2), reader.GetString(3));
            reader.Close();
            db.CloseConnection();
            label_greetings.Text = "Здравствуйте, " + this.user.Name;
            this.authorization = authorization;
        }

        /// <summary>
        /// Метод, который устанавливает номер нового заказа
        /// </summary>
        private void SetOrderNumber()
        {
            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT MAX(id_o) FROM orders", db.GetConnection);
            MySqlDataReader reader = cmd.ExecuteReader();
            if (!reader.HasRows)
            {
                reader.Close();
                textBox_orderIndex.Text = "1";
                return;
            }
            reader.Read();
            int id_o = reader.GetInt32(0) + 1;
            textBox_orderIndex.Text = id_o.ToString();
            reader.Close();
        }

        /// <summary>
        /// Метод, который задаёт колонки таблицы
        /// </summary>
        private void HeaderOfTheTable()
        {
            var column1 = new DataGridViewColumn();
            column1.HeaderText = "Номер заказа";
            column1.Width = 100;
            column1.Name = "id_o";
            column1.CellTemplate = new DataGridViewTextBoxCell();

            var column2 = new DataGridViewColumn();
            column2.HeaderText = "Дата оформления";
            column2.Width = 100;
            column2.Name = "o_date";
            column2.CellTemplate = new DataGridViewTextBoxCell();

            var column3 = new DataGridViewColumn();
            column3.HeaderText = "Клиент";
            column3.Width = 100;
            column3.Name = "client";
            column3.CellTemplate = new DataGridViewTextBoxCell();

            var column4 = new DataGridViewColumn();
            column4.HeaderText = "Услуга";
            column4.Width = 125;
            column4.Name = "service";
            column4.CellTemplate = new DataGridViewTextBoxCell();

            var column5 = new DataGridViewColumn();
            column5.HeaderText = "Статус обработки";
            column5.Width = 100;
            column5.Name = "status";
            column5.CellTemplate = new DataGridViewTextBoxCell();     

            dataGrid.Columns.Add(column1);
            dataGrid.Columns.Add(column2);
            dataGrid.Columns.Add(column3);
            dataGrid.Columns.Add(column4);
            dataGrid.Columns.Add(column5);

            dataGrid.AllowUserToAddRows = false; // Запрещаем пользователю самому добавлять строки
            dataGrid.Columns[1].ReadOnly = true;
        }

        /// <summary>
        /// Заполнение таблицы данными из БД
        /// </summary>
        private void FillTable()
        {
            dataGrid.Rows.Clear();
            MySqlCommand cmd = new MySqlCommand("SELECT orders.id_o, orders.o_date, clients.name, services.name, orders.o_status " +
                                                "FROM orders, clients, services WHERE orders.id_cl = clients.id_cl AND orders.id_s = services.id_s " +
                                                "ORDER BY orders.id_o", db.GetConnection);
            db.OpenConnection();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                dataGrid.Rows.Add(reader.GetInt32(0), reader.GetDateTime(1), reader.GetString(2),
                                  reader.GetString(3), reader.GetString(4));
            }
            reader.Close();
            db.CloseConnection();
        }

        /// <summary>
        /// Метод, который заполняет выпадающий список с клиентами
        /// </summary>
        private void FillClientsComboBox()
        {
            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT id_cl, name FROM clients", db.GetConnection);
            MySqlDataReader reader = cmd.ExecuteReader();
            if (!reader.HasRows)
            {
                comboBox_clients.Items.Clear();
                comboBox_clients.Text = "Список клиентов пуст";
                return;
            }
            while (reader.Read())
            {
                comboBox_clients.Items.Add(reader.GetInt32(0).ToString() + " " + reader.GetString(1));
            }
            reader.Close();
            db.CloseConnection();
        }

        /// <summary>
        /// Метод, который заполняет выпадающий список с услугами элементами из БД
        /// </summary>
        private void FillServicesComboBox()
        {
            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT id_s, name FROM services", db.GetConnection);
            MySqlDataReader reader = cmd.ExecuteReader();
            if (!reader.HasRows)
            {
                comboBox_service.Items.Clear();
                comboBox_service.Text = "Список услуг пуст";
                return;
            }
            while (reader.Read())
            {
                comboBox_service.Items.Add(reader.GetInt32(0).ToString() + " " + reader.GetString(1));
            }
            reader.Close();
            db.CloseConnection();
        }

        /// <summary>
        /// Метод, который устанавливает значение цены выбранной услуги в соответствующее поле
        /// </summary>
        /// <param name="id_s">Идентификатор (номер) услуги</param>
        private void SetServicePrice(int id_s)
        {
            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT price FROM services " +
                "WHERE id_s = @id_s", db.GetConnection);
            cmd.Parameters.Add("id_s", MySqlDbType.Int32).Value = id_s;
            MySqlDataReader reader = cmd.ExecuteReader();
            reader.Read();
            price = reader.GetFloat(0);
            textBox_price.Text = price.ToString();

            reader.Close();
            db.CloseConnection();
        }

        /// <summary>
        /// Обработчик события, возникающего при загрузке формы OrderLog
        /// </summary>
        private void OrderLog_Load(object sender, EventArgs e)
        {
            HeaderOfTheTable();
            FillTable();
            SetOrderNumber();
            FillClientsComboBox();
            FillServicesComboBox();
        }

        /// <summary>
        /// Обработчик события изменения выбранного элемента из выпадающего списка с услугами
        /// </summary>
        private void comboBox_service_SelectedValueChanged(object sender, EventArgs e)
        {
            int id_s = Int32.Parse(comboBox_service.Text.Split(' ')[0]);
            SetServicePrice(id_s);
        }

        /// <summary>
        /// Обработчик события изменения значения скидки в соответствующем текстовом поле
        /// </summary>
        private void textBox_discounte_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToSingle(textBox_discounte.Text) > 100)
                {
                    textBox_discounte.Text = 100.ToString();
                }
                if (Convert.ToSingle(textBox_discounte.Text) < 0 || textBox_discounte.Text.Length == 0)
                {
                    textBox_discounte.Text = 0.ToString();
                }
                textBox_price.Text = 
                    Math.Round(price - (Convert.ToSingle(textBox_price.Text) * (Convert.ToInt32(textBox_discounte.Text) / 100.0)), 1).ToString();
            } catch
            {
                

            }
        }

        /// <summary>
        /// Метод, который очищает поля ввода на форме OrderLog
        /// </summary>
        private void ClearEntryFields()
        {
            SetOrderNumber();
            comboBox_clients.Text = string.Empty;
            comboBox_service.Text = string.Empty;
            textBox_price.Text = string.Empty;
            textBox_discounte.Text = "0";
            checkBox_Status.Checked = false;
        }

        /// <summary>
        /// Обработчик события нажатия на кнопку "Сохранить заказ"
        /// </summary>
        private void button_saveOrder_Click(object sender, EventArgs e)
        {
            if (comboBox_clients.Text.Length == 0 || comboBox_service.Text.Length == 0)
            {
                MessageBox.Show("Для оформления заказа нужно выбрать клиента и услугу.", "Ошибка!");
                return;
            }

            try
            {
                Convert.ToSingle(textBox_discounte.Text);
            } catch { MessageBox.Show("Некорректное значение скидки.", "Ошибка"); }

            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("INSERT INTO " +
                "orders(id_o, o_date, id_cl, id_s, id_emp, discount, o_status) " +
                "VALUES(0, @o_date, @id_cl, @id_s, @id_emp, @discount, @o_status)", db.GetConnection);
            cmd.Parameters.Add("o_date", MySqlDbType.DateTime).Value = dateTimePicker_orderCreate.Value;
            cmd.Parameters.Add("id_cl", MySqlDbType.Int32).Value = Int32.Parse(comboBox_clients.Text.Split(' ')[0]);
            cmd.Parameters.Add("id_s", MySqlDbType.Int32).Value = Int32.Parse(comboBox_service.Text.Split(' ')[0]);
            cmd.Parameters.Add("id_emp", MySqlDbType.Int32).Value = this.user.Id;
            cmd.Parameters.Add("discount", MySqlDbType.Float).Value = Convert.ToSingle(textBox_discounte.Text);
            if (checkBox_Status.Checked == false) cmd.Parameters.Add("o_status", MySqlDbType.VarChar).Value = "не выполнен";
            else cmd.Parameters.Add("o_status", MySqlDbType.VarChar).Value = "выполнен";

            cmd.ExecuteNonQuery();
            db.CloseConnection();
            FillTable();
            ClearEntryFields();
        }

        /// <summary>
        /// Обработчик события нажатия на кнопку "Выйти"
        /// </summary>
        private void button_logOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.authorization.Show();
        }

        /// <summary>
        /// Обработчик события, возникающего при закрытии формы OrderLog, нажатием на кнопку "Закрыть"
        /// (крестик) в правом верхнем углу окна приложения
        /// </summary>
        private void OrderLog_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
