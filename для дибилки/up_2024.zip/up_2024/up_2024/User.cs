﻿namespace up_2024
{
    /// <summary>
    /// Класс, описывающий авторизованного пользователя
    /// </summary>
    public class User
    {
        int id;
        string name;
        string login;
        string password;

        public User (string login, string password)
        {
            this.login = login;
            this.password = password;
        }

        public User(int id, string name, string login, string password)
        {
            this.id = id;
            this.name = name;
            this.login = login;
            this.password = password;
        }

        public int Id
        {
            get { return id; }
            set { this.id = value; }
        }

        public string Name
        {
            get { return name; }
            set { this.name = value; }
        }
        public string Login
        {
            get { return this.login; }
            set { this.login = value; }
        }
        public string Password
        {
            get { return this.password;}
            set { this.password = value; }
        }
    }
}
