﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace up_2024
{
    public partial class ClientRegistration : Form
    {
        Authorization parent;
        public ClientRegistration()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Конструктор формы с параметрами, для связи с родительской формой
        /// </summary>
        /// <param name="parent">Родительская форма</param>
        public ClientRegistration(Authorization parent)
        {
            InitializeComponent();
            this.parent = parent;
        }

        /// <summary>
        /// Обработчик события, возникающего при закрытии формы ClientRegistration, нажатием на кнопку "Закрыть"
        /// (крестик) в правом верхнем углу окна приложения
        /// </summary>
        private void ClientRegistration_FormClosed(object sender, FormClosedEventArgs e)
        {
            parent.Show();
        }

        /// <summary>
        /// Обработка события нажатия на кнопку "Сохранить данные"
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox_name.Text;
            string address = textBox_address.Text;
            string phone_number = maskedTextBox_phoneNumber.Text;

            if (name.Length == 0 || address.Length == 0 || phone_number.Length == 0)
            {
                MessageBox.Show("Все поля должны быть заполнены.", "Ошибка!");
                return;
            }
            DatabaseManager db = new DatabaseManager();
            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("INSERT INTO clients " +
                "VALUES(0, @name, @address, @phone_number)", db.GetConnection);
            cmd.Parameters.Add("name", MySqlDbType.VarChar).Value = name;
            cmd.Parameters.Add("address", MySqlDbType.VarChar).Value = address;
            cmd.Parameters.Add("phone_number", MySqlDbType.VarChar).Value = phone_number;
            cmd.ExecuteNonQuery();
            db.CloseConnection();
            textBox_name.Text = "";
            textBox_address.Text = "";
            maskedTextBox_phoneNumber.Text = "";
        }
    }
}
