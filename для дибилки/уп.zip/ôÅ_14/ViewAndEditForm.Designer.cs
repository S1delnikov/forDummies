﻿namespace УП_14
{
    partial class ViewAndEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.добавлениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.просмотрИРедактированиеДанныхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.круговаяДиаграммаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateButton = new System.Windows.Forms.Button();
            this.changeButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.tableOptionButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView
            // 
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(12, 91);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersWidth = 51;
            this.dataGridView.RowTemplate.Height = 24;
            this.dataGridView.Size = new System.Drawing.Size(776, 402);
            this.dataGridView.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.LightSkyBlue;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавлениеToolStripMenuItem,
            this.просмотрИРедактированиеДанныхToolStripMenuItem,
            this.круговаяДиаграммаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 36);
            this.menuStrip1.TabIndex = 22;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // добавлениеToolStripMenuItem
            // 
            this.добавлениеToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.добавлениеToolStripMenuItem.Name = "добавлениеToolStripMenuItem";
            this.добавлениеToolStripMenuItem.Size = new System.Drawing.Size(145, 32);
            this.добавлениеToolStripMenuItem.Text = "Добавление ";
            this.добавлениеToolStripMenuItem.Click += new System.EventHandler(this.добавлениеToolStripMenuItem_Click);
            // 
            // просмотрИРедактированиеДанныхToolStripMenuItem
            // 
            this.просмотрИРедактированиеДанныхToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.просмотрИРедактированиеДанныхToolStripMenuItem.Name = "просмотрИРедактированиеДанныхToolStripMenuItem";
            this.просмотрИРедактированиеДанныхToolStripMenuItem.Size = new System.Drawing.Size(366, 32);
            this.просмотрИРедактированиеДанныхToolStripMenuItem.Text = "Просмотр и редактирование данных";
            // 
            // круговаяДиаграммаToolStripMenuItem
            // 
            this.круговаяДиаграммаToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.круговаяДиаграммаToolStripMenuItem.Name = "круговаяДиаграммаToolStripMenuItem";
            this.круговаяДиаграммаToolStripMenuItem.Size = new System.Drawing.Size(217, 32);
            this.круговаяДиаграммаToolStripMenuItem.Text = "Круговая диаграмма";
            this.круговаяДиаграммаToolStripMenuItem.Click += new System.EventHandler(this.круговаяДиаграммаToolStripMenuItem_Click);
            // 
            // updateButton
            // 
            this.updateButton.Location = new System.Drawing.Point(12, 50);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(156, 35);
            this.updateButton.TabIndex = 23;
            this.updateButton.Text = "Обновить данные";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // changeButton
            // 
            this.changeButton.Location = new System.Drawing.Point(199, 50);
            this.changeButton.Name = "changeButton";
            this.changeButton.Size = new System.Drawing.Size(156, 35);
            this.changeButton.TabIndex = 24;
            this.changeButton.Text = "Внести изменения";
            this.changeButton.UseVisualStyleBackColor = true;
            this.changeButton.Click += new System.EventHandler(this.changeButton_Click);
            // 
            // deleteButton
            // 
            this.deleteButton.Location = new System.Drawing.Point(384, 50);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(156, 35);
            this.deleteButton.TabIndex = 25;
            this.deleteButton.Text = "Удалить выбранное";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // tableOptionButton
            // 
            this.tableOptionButton.Location = new System.Drawing.Point(569, 50);
            this.tableOptionButton.Name = "tableOptionButton";
            this.tableOptionButton.Size = new System.Drawing.Size(163, 35);
            this.tableOptionButton.TabIndex = 26;
            this.tableOptionButton.Text = "Параметры таблицы";
            this.tableOptionButton.UseVisualStyleBackColor = true;
            this.tableOptionButton.Click += new System.EventHandler(this.tableOptionButton_Click);
            // 
            // ViewAndEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CornflowerBlue;
            this.ClientSize = new System.Drawing.Size(800, 505);
            this.Controls.Add(this.tableOptionButton);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.changeButton);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.dataGridView);
            this.MaximumSize = new System.Drawing.Size(818, 552);
            this.MinimumSize = new System.Drawing.Size(818, 552);
            this.Name = "ViewAndEditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Просмотр и редактирование данных";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ViewAndEditForm_FormClosed);
            this.Shown += new System.EventHandler(this.ViewAndEditForm_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem добавлениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem просмотрИРедактированиеДанныхToolStripMenuItem;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button changeButton;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button tableOptionButton;
        private System.Windows.Forms.ToolStripMenuItem круговаяДиаграммаToolStripMenuItem;
    }
}