﻿
namespace УП_14
{
    public class Flags
    {
        static public bool flag1 = true, flag2 = true, flag3 = true, flag4 = true, flag5 = true, flag6 = true,
           flag7 = true, flag8 = true, flag9 = true, flag10 = true, flag11 = true, flag12 = true,
           flag13 = true, flag14 = true;
    }
}
