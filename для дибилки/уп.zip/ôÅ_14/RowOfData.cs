﻿
namespace УП_14
{
    // Представление одной строки данных
    internal class RowOfData
    {
        public object date_admission { get; set;}
        public object number { get; set;}
        public object surname { get; set;} 
        public object name { get; set;}
        public object patronimyc { get; set; }
        public object date_birthday { get; set; }
        public object sex { get; set; }
        public object passport_serie { get; set; }
        public object passport_number { get; set; }
        public object education_type { get; set; }
        public object university { get; set; }
        public object date_graduation { get; set; }
        public object mobilePhone { get; set; }
        public object email { get; set; }

        public RowOfData() { }
        public RowOfData(object date_admission, object number, object surname, object name,
            object patronimyc, object date_birthday, object sex, object passport_serie, object passport_number,
            object education_type, object university, object date_graduation, object mobilePhone, object email)
        {
            this.date_admission = date_admission;
            this.number = number;
            this.surname = surname;
            this.name = name;
            this.patronimyc = patronimyc;
            this.date_birthday = date_birthday;
            this.sex = sex;
            this.passport_serie = passport_serie;
            this.passport_number = passport_number;
            this.education_type = education_type;
            this.university = university;
            this.date_graduation = date_graduation;
            this.mobilePhone = mobilePhone;
            this.email = email;
        }
    }
}
