﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace УП_14
{
    public partial class TableOptions : Form
    {
        public TableOptions()
        {
            InitializeComponent();
        }

        private void TableOptions_Shown(object sender, EventArgs e)
        {
            ViewAndEditForm form = new ViewAndEditForm();

            if (Flags.flag1 == true) dateAdmissionCheckBox.Checked = true;
            else dateAdmissionCheckBox.Checked = false;

            if (Flags.flag2 == true) numberCheckBox.Checked = true;
            else numberCheckBox.Checked = false;

            if (Flags.flag3 == true) surnameCheckBox.Checked = true;
            else surnameCheckBox.Checked = false;

            if (Flags.flag4 == true) nameCheckBox.Checked = true;
            else nameCheckBox.Checked = false;

            if(Flags.flag5 == true) patronimycCheckBox.Checked = true;
            else patronimycCheckBox.Checked = false;

            if (Flags.flag6 == true) dateBirthdayCheckBox.Checked = true;
            else dateBirthdayCheckBox.Checked = false;

            if (Flags.flag7 == true) sexCheckBox.Checked = true;
            else sexCheckBox.Checked = false;

            if (Flags.flag8 == true) seriePassportCheckBox.Checked = true;
            else seriePassportCheckBox.Checked = false;

            if (Flags.flag9 == true) numberPassportCheckBox.Checked = true;
            else numberPassportCheckBox.Checked = false;

            if (Flags.flag10 == true) educationTypeCheckBox.Checked = true;
            else educationTypeCheckBox.Checked = false;

            if (Flags.flag11 == true) universityCheckBox.Checked = true;
            else universityCheckBox.Checked = false;

            if (Flags.flag12 == true) dateGraduationCheckBox.Checked = true;
            else dateGraduationCheckBox.Checked = false;

            if (Flags.flag13 == true) mobilePhoneCheckBox.Checked = true;
            else mobilePhoneCheckBox.Checked = false;

            if (Flags.flag14 == true) emailCheckBox.Checked = true;
            else emailCheckBox.Checked = false;
        }

        // Кнопка применения параметров таблицы
        private void applyButton_Click(object sender, EventArgs e)
        {
            ViewAndEditForm form = new ViewAndEditForm();

            if (dateAdmissionCheckBox.Checked == true) Flags.flag1 = true;
            else Flags.flag1 = false;

            if (numberCheckBox.Checked == true) Flags.flag2 = true;
            else Flags.flag2 = false;

            if (surnameCheckBox.Checked == true) Flags.flag3 = true;
            else Flags.flag3 = false;

            if (nameCheckBox.Checked == true) Flags.flag4 = true;
            else Flags.flag4 = false;

            if (patronimycCheckBox.Checked == true) Flags.flag5 = true;
            else Flags.flag5 = false;

            if (dateBirthdayCheckBox.Checked == true) Flags.flag6 = true;
            else Flags.flag6 = false;

            if (sexCheckBox.Checked == true) Flags.flag7 = true;
            else Flags.flag7 = false;

            if (seriePassportCheckBox.Checked == true) Flags.flag8 = true;
            else Flags.flag8 = false;

            if (numberPassportCheckBox.Checked == true) Flags.flag9 = true;
            else Flags.flag9 = false;

            if (educationTypeCheckBox.Checked == true) Flags.flag10 = true;
            else Flags.flag10 = false;

            if (universityCheckBox.Checked == true) Flags.flag11 = true;
            else Flags.flag11 = false;

            if (dateGraduationCheckBox.Checked == true) Flags.flag12 = true;
            else Flags.flag12 = false;

            if (mobilePhoneCheckBox.Checked == true) Flags.flag13 = true;
            else Flags.flag13 = false;

            if (emailCheckBox.Checked == true) Flags.flag14 = true;
            else Flags.flag14 = false;

            this.Hide();
            form.Show();
        }

        private void TableOptions_FormClosed(object sender, FormClosedEventArgs e)
        {
            ViewAndEditForm form = new ViewAndEditForm();
            form.Show();
        }

        // Кнопка выделения всех параметров таблицы
        private void markAll_Click(object sender, EventArgs e)
        {
            foreach (var checkBox in Controls.OfType<CheckBox>())
                checkBox.Checked = true;
        }

        // Кнопка снятия выделения со всех параметров таблицы
        private void unMarkAll_Click(object sender, EventArgs e)
        {
            foreach (var checkBox in Controls.OfType<CheckBox>())
                checkBox.Checked = false;
        }
    }
}
