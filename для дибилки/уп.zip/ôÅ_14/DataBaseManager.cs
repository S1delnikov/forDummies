﻿using MySql.Data.MySqlClient;

namespace Бельчич_15_1
{
    internal class DataBaseManager
    {
        // Создаём поле данных для соединения с базой данных
        MySqlConnection connection = new MySqlConnection
            (
            "server = localhost;" +
            "port = 3306;" +
            "username = root;" +
            "password =;" +
            "database = up_v_14"
            );

        // Метод, который открывает соединение
        public void OpenConnection()
        {
            // Проверяем состояние подключения
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();
        }

        // Закрываем соединение
        public void CloseConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
        }

        public MySqlConnection GetConnection { get { return connection; } }
    }
}
