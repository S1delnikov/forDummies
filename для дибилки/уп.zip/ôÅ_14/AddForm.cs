﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Windows.Forms;
using Бельчич_15_1;

namespace УП_14
{
    public partial class AddForm : Form
    {
        public AddForm()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Точно добавить эти данные?", "Внимание!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    Crypto crypto = new Crypto();
                    DataBaseManager _manager = new DataBaseManager();
                    // <Вводимые данные> 
                    DateTime admissionDate = Convert.ToDateTime(admissionDateTimePicker.Value);
                    int number = Convert.ToInt32(numberTextBox.Text);
                    string surname = surnameTextBox.Text;
                    string name = nameTextBox.Text;
                    string patronimyc = patronimycTextBox.Text;
                    DateTime birthday = Convert.ToDateTime(birthdayDateTimePicker.Value);
                    string sex = sexComboBox.Text;
                    string passport = passportMaskedTextBox.Text;
                    string education = educationComboBox.Text;
                    string university = universityTextBox.Text;
                    DateTime graduation = Convert.ToDateTime(graduationDateTimePicker.Value);
                    string mobilePhone = mobilePhoneMaskedTextBox.Text;
                    string email = emailTextBox.Text == "example@mail.ru" ? "" : emailTextBox.Text;
                    // </Вводимые данные> 

                    // <Формирование запросов к базе данных>
                    MySqlCommand insertIntoStudent = new MySqlCommand("INSERT INTO student VALUES (@number, @admissionDate, @surname, @name, @patronimyc, @birthday, @sex)",
                        _manager.GetConnection);
                    insertIntoStudent.Parameters.Add("@number", MySqlDbType.Int32).Value = number;
                    insertIntoStudent.Parameters.Add("@admissionDate", MySqlDbType.Date).Value = admissionDate;
                    insertIntoStudent.Parameters.Add("@surname", MySqlDbType.VarChar).Value = surname;
                    insertIntoStudent.Parameters.Add("@name", MySqlDbType.VarChar).Value = name;
                    insertIntoStudent.Parameters.Add("@patronimyc", MySqlDbType.VarChar).Value = patronimyc;
                    insertIntoStudent.Parameters.Add("@birthday", MySqlDbType.Date).Value = birthday;
                    insertIntoStudent.Parameters.Add("@sex", MySqlDbType.VarChar).Value = sex;

                    MySqlCommand insertIntoEducation = new MySqlCommand("INSERT INTO education VALUES (@education_id, @education, @university, @graduation, @number)",
                        _manager.GetConnection);
                    insertIntoEducation.Parameters.Add("@education_id", MySqlDbType.Int32).Value = 0;
                    insertIntoEducation.Parameters.Add("@education", MySqlDbType.VarChar).Value = education;
                    insertIntoEducation.Parameters.Add("@university", MySqlDbType.VarChar).Value = university;
                    insertIntoEducation.Parameters.Add("@graduation", MySqlDbType.Date).Value = graduation;
                    insertIntoEducation.Parameters.Add("@number", MySqlDbType.Int32).Value = number;

                    MySqlCommand insertIntoPassport = new MySqlCommand("INSERT INTO passport VALUES (@passport_id, @series, @number, @student_id)",
                        _manager.GetConnection);
                    insertIntoPassport.Parameters.Add("@passport_id", MySqlDbType.Int32).Value = 0;
                    insertIntoPassport.Parameters.Add("@series", MySqlDbType.Int32).Value = crypto.EncryptSeries(passport);
                    insertIntoPassport.Parameters.Add("@number", MySqlDbType.Int32).Value = crypto.EncryptNumber(passport);
                    insertIntoPassport.Parameters.Add("@student_id", MySqlDbType.Int32).Value = number;

                    MySqlCommand insertIntoContacts = new MySqlCommand("INSERT INTO contacts VALUES (@contact_id, @mobilePhone, @email, @number)",
                        _manager.GetConnection);
                    insertIntoContacts.Parameters.Add("@contact_id", MySqlDbType.Int32).Value = 0;
                    insertIntoContacts.Parameters.Add("@mobilePhone", MySqlDbType.VarChar).Value = mobilePhone;
                    insertIntoContacts.Parameters.Add("@email", MySqlDbType.VarChar).Value = email;
                    insertIntoContacts.Parameters.Add("@number", MySqlDbType.Int32).Value = number;
                    // </Формирование запросов к базе данных>

                    if (CheckTheUniquenessOfThePassport(passport) == false)
                    {
                        MessageBox.Show("Студент с данными паспортными данными уже существует.", "Ошибка!");
                        return;
                    }
                    _manager.OpenConnection();
                    insertIntoStudent.ExecuteNonQuery();
                    insertIntoEducation.ExecuteNonQuery();
                    insertIntoPassport.ExecuteNonQuery();
                    insertIntoContacts.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно добавлены", "Внимание!");
                    _manager.CloseConnection();

                    AddForm form = new AddForm();
                    this.Hide();
                    form.Show();
                }
                catch (MySqlException) { MessageBox.Show("Запись с таким номером уже существует.", "Ошибка!"); } 
                catch { MessageBox.Show("Что-то пошло не так.\nПроверьте корректность вводимых данных. Убедитесь, что все поля, отмеченные звёздочкой, заполнены корректно.", "Ошибка"); }
            }
        }

        private void просмотрИРедактированиеДанныхToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewAndEditForm form = new ViewAndEditForm();
            this.Hide();
            form.Show();
        }

        private void AddForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void круговаяДиаграммаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PieChartForm form = new PieChartForm();
            form.Show();
        }

        private void AddForm_Shown(object sender, EventArgs e)
        {
            DataBaseManager _manager = new DataBaseManager();
            MySqlCommand selectMaxStudentId = new MySqlCommand("SELECT MAX(student_id) FROM student", _manager.GetConnection);
            _manager.OpenConnection();
            if (selectMaxStudentId.ExecuteScalar() == DBNull.Value)
                numberTextBox.Text = 1.ToString();
            else
                numberTextBox.Text = (Convert.ToInt32(selectMaxStudentId.ExecuteScalar()) + 1).ToString();
            _manager.CloseConnection();
        }

        // При нажатии на поле ввода  email'а, подсказка удаляется
        private void emailTextBox_Enter(object sender, EventArgs e)
        {
            emailTextBox.Text = null;
            emailTextBox.ForeColor = Color.Black;
        }

        // При снятие фокуса с поля ввода email'а подсказка возвращается, при условии, что пользователь ничего не ввёл
        private void emailTextBox_Leave(object sender, EventArgs e)
        {
            if (emailTextBox.Text == "")
            {
                emailTextBox.ForeColor = Color.LightGray;
                emailTextBox.Text = "example@mail.ru";
            }
        }

        // Проверка уникальности серии и номера паспорта
        private bool CheckTheUniquenessOfThePassport(string passport)
        {
            Crypto crypto = new Crypto();
            string[] serieAndNumber = passport.Split();
            DataBaseManager manager = new DataBaseManager();
            MySqlCommand command = new MySqlCommand("SELECT COUNT(student_id) FROM passport WHERE series = @series AND number = @number", manager.GetConnection);
            command.Parameters.Add("@series", MySqlDbType.Int32).Value = crypto.EncryptSeries(passport);
            command.Parameters.Add("@number", MySqlDbType.Int32).Value = crypto.EncryptNumber(passport);
            manager.OpenConnection();
            int student_id = Convert.ToInt32(command.ExecuteScalar());
            manager.CloseConnection();

            if (student_id > 0) return false;
            return true;
        }
    }
}
