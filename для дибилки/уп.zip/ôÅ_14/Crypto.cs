﻿using System;

namespace УП_14
{
    // Класс с методами для изменения представления данных о серии и номере паспорта в базе данных
    internal class Crypto
    {
        public int EncryptSeries(string passport)
        {
            int serie = passport.Split().Length > 1 ? Convert.ToInt32(passport.Split()[0] + passport.Split()[1]) : Convert.ToInt32(passport);
            return serie * 2;
        }

        public int EncryptNumber(string passport)
        {
            int number = passport.Split().Length > 1 ? Convert.ToInt32(passport.Split()[2]) : Convert.ToInt32(passport);
            return number * 2;
        }

        public int DecryptSerieOrNumber(int serie)
        {
            return serie / 2;
        }
    }
}
