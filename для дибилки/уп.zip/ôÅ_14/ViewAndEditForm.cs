﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Бельчич_15_1;

namespace УП_14
{
    public partial class ViewAndEditForm : Form
    {
        public ViewAndEditForm()
        {
            InitializeComponent();
        }

        private void tableOptionButton_Click(object sender, EventArgs e)
        {
            TableOptions form = new TableOptions();
            this.Hide();
            form.ShowDialog();
        }

        public void HeaderOfTheTable()
        {
            var column1 = new DataGridViewColumn();
            column1.HeaderText = "Дата приёма";
            column1.Width = 100;
            column1.Name = "date_admission";
            column1.Visible = Flags.flag1;
            column1.CellTemplate = new DataGridViewTextBoxCell();

            var column2 = new DataGridViewColumn();
            column2.HeaderText = "Номер";
            column2.Width = 100;
            column2.Name = "number";
            column2.Visible = Flags.flag2;
            column2.CellTemplate = new DataGridViewTextBoxCell();

            var column3 = new DataGridViewColumn();
            column3.HeaderText = "Фамилия";
            column3.Width = 100;
            column3.Name = "surname";
            column3.Visible = Flags.flag3;
            column3.CellTemplate = new DataGridViewTextBoxCell();

            var column4 = new DataGridViewColumn();
            column4.HeaderText = "Имя";
            column4.Width = 100;
            column4.Name = "name";
            column4.Visible = Flags.flag4;
            column4.CellTemplate = new DataGridViewTextBoxCell();

            var column5 = new DataGridViewColumn();
            column5.HeaderText = "Отчество";
            column5.Width = 100;
            column5.Name = "patronimyc";
            column5.Visible = Flags.flag5;
            column5.CellTemplate = new DataGridViewTextBoxCell();

            var column6 = new DataGridViewColumn();
            column6.HeaderText = "Дата рождения";
            column6.Width = 100;
            column6.Name = "date_birthday";
            column6.Visible = Flags.flag6;
            column6.CellTemplate = new DataGridViewTextBoxCell();

            var column7 = new DataGridViewColumn();
            column7.HeaderText = "Пол";
            column7.Width = 100;
            column7.Name = "sex";
            column7.Visible = Flags.flag7;
            column7.CellTemplate = new DataGridViewTextBoxCell();

            var column8 = new DataGridViewColumn();
            column8.HeaderText = "Серия паспорта";
            column8.Width = 100;
            column8.Name = "passport_serie";
            column8.Visible = Flags.flag8;
            column8.CellTemplate = new DataGridViewTextBoxCell();

            var column9 = new DataGridViewColumn();
            column9.HeaderText = "Номер паспорта";
            column9.Width = 100;
            column9.Name = "passport_number";
            column9.Visible = Flags.flag9;
            column9.CellTemplate = new DataGridViewTextBoxCell();

            var column10 = new DataGridViewColumn();
            column10.HeaderText = "Образование";
            column10.Width = 100;
            column10.Name = "education_type";
            column10.Visible = Flags.flag10;
            column10.CellTemplate = new DataGridViewTextBoxCell();

            var column11 = new DataGridViewColumn();
            column11.HeaderText = "Учебное заведение";
            column11.Width = 100;
            column11.Name = "university";
            column11.Visible = Flags.flag11;
            column11.CellTemplate = new DataGridViewTextBoxCell();

            var column12 = new DataGridViewColumn();
            column12.HeaderText = "Дата окончания";
            column12.Width = 100;
            column12.Name = "date_graduation";
            column12.Visible = Flags.flag12;
            column12.CellTemplate = new DataGridViewTextBoxCell();

            var column13 = new DataGridViewColumn();
            column13.HeaderText = "Телефон";
            column13.Width = 100;
            column13.Name = "mobilePhone";
            column13.Visible = Flags.flag13;
            column13.CellTemplate = new DataGridViewTextBoxCell();

            var column14 = new DataGridViewColumn();
            column14.HeaderText = "Эл.почта";
            column14.Width = 100;
            column14.Name = "email";
            column14.Visible = Flags.flag14;
            column14.CellTemplate = new DataGridViewTextBoxCell();

            dataGridView.Columns.Add(column1);
            dataGridView.Columns.Add(column2);
            dataGridView.Columns.Add(column3);
            dataGridView.Columns.Add(column4);
            dataGridView.Columns.Add(column5);
            dataGridView.Columns.Add(column6);
            dataGridView.Columns.Add(column7);
            dataGridView.Columns.Add(column8);
            dataGridView.Columns.Add(column9);
            dataGridView.Columns.Add(column10);
            dataGridView.Columns.Add(column11);
            dataGridView.Columns.Add(column12);
            dataGridView.Columns.Add(column13);
            dataGridView.Columns.Add(column14);

            dataGridView.AllowUserToAddRows = false; // Запрещаем пользователю самому добавлять строки
            dataGridView.Columns[1].ReadOnly = true;
        }

        List<RowOfData> rows = new List<RowOfData>();
        public void FillTable()
        {
            Crypto crypto = new Crypto();
            dataGridView.Rows.Clear();
            MySqlDataReader reader;
            DataBaseManager manager = new DataBaseManager();
            MySqlCommand command = new MySqlCommand(
                "SELECT * FROM student, education, passport, contacts WHERE student.student_id = education.student_id AND student.student_id = passport.student_id AND student.student_id = contacts.student_id", 
                manager.GetConnection);
            MySqlDataAdapter dataAdapter = new MySqlDataAdapter();
            DataTable dataTable = new DataTable();

            dataAdapter.SelectCommand = command;
            dataAdapter.Fill(dataTable);
            manager.OpenConnection();
            reader = command.ExecuteReader();

            while (reader.Read())
            {
                RowOfData row = new RowOfData(
                    reader["admission"], reader["student_id"], reader["surname"], 
                    reader["name"], reader["patronimyc"], reader["birthday"],
                    reader["sex"], reader["series"], reader["number"],
                    reader["type"], reader["university"], reader["graduation"],
                    reader["mobile_phone"], reader["email"]);

                dataGridView.Rows.Add(row.date_admission, row.number, row.surname, row.name, row.patronimyc,
                    row.date_birthday, row.sex, crypto.DecryptSerieOrNumber(Convert.ToInt32(row.passport_serie)), 
                    crypto.DecryptSerieOrNumber(Convert.ToInt32(row.passport_number)), row.education_type,
                    row.university, row.date_graduation, row.mobilePhone, row.email);
            }
            manager.CloseConnection();
        }

        private void ViewAndEditForm_Shown(object sender, EventArgs e)
        {
            HeaderOfTheTable();
            FillTable();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            FillTable();
        }

        private void добавлениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddForm form = new AddForm();
            this.Hide();
            form.Show();
        }

        // Кнопка изменения данных в базе данных
        private void changeButton_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Точно внести изменения?", "Внимание!", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    for (int i = 0; i < dataGridView.Rows.Count; i++)
                    {
                        MakeUpdateQuery("student", new string[]{dataGridView.Rows[i].Cells[1].Value.ToString(), dataGridView.Rows[i].Cells[0].Value.ToString(),
                            dataGridView.Rows[i].Cells[2].Value.ToString(), dataGridView.Rows[i].Cells[3].Value.ToString(), dataGridView.Rows[i].Cells[4].Value.ToString(),
                            dataGridView.Rows[i].Cells[5].Value.ToString(), dataGridView.Rows[i].Cells[6].Value.ToString()});

                        MakeUpdateQuery("education", new string[] {dataGridView.Rows[i].Cells[1].Value.ToString(), dataGridView.Rows[i].Cells[9].Value.ToString(),
                        dataGridView.Rows[i].Cells[10].Value.ToString(), dataGridView.Rows[i].Cells[11].Value.ToString()});

                        MakeUpdateQuery("passport", new string[] { dataGridView.Rows[i].Cells[1].Value.ToString(), dataGridView.Rows[i].Cells[7].Value.ToString(),
                        dataGridView.Rows[i].Cells[8].Value.ToString()});

                        MakeUpdateQuery("contacts", new string[] { dataGridView.Rows[i].Cells[1].Value.ToString(), dataGridView.Rows[i].Cells[12].Value.ToString(),
                        dataGridView.Rows[i].Cells[13].Value.ToString()});
                    }
                    MessageBox.Show("Данные изменены.", "Внимание!");
                    FillTable();
                }
                catch { MessageBox.Show("Что-то пошло не так.", "Ошибка!"); }
            }    
        }

        // Метод выполняет Update-запрос к таблице, имя которой передаётся в качестве параметра
        public void MakeUpdateQuery(string pointer, params string[] args)
        {
            if (pointer == "student")
            {
                string student_id = args[0];
                DateTime admission = Convert.ToDateTime(args[1]);
                string surname = args[2];
                string name = args[3];
                string patronimyc = args[4];
                DateTime birthday = Convert.ToDateTime(args[5]);
                string sex = args[6];

                DataBaseManager manager = new DataBaseManager();
                MySqlCommand command = new MySqlCommand("UPDATE student SET admission = @admission, " +
                    "surname = @surname, name = @name, patronimyc = @patronimyc, birthday = @birthday, sex = @sex WHERE student_id = @student_id", manager.GetConnection);

                command.Parameters.Add("@student_id", MySqlDbType.Int32).Value = Convert.ToInt32(student_id);
                command.Parameters.Add("@admission", MySqlDbType.Date).Value = admission;
                command.Parameters.Add("@surname", MySqlDbType.VarChar).Value = surname;
                command.Parameters.Add("@name", MySqlDbType.VarChar).Value = name;
                command.Parameters.Add("@patronimyc", MySqlDbType.VarChar).Value = patronimyc;
                command.Parameters.Add("@birthday", MySqlDbType.Date).Value = birthday;
                command.Parameters.Add("@sex", MySqlDbType.VarChar).Value = sex;

                manager.OpenConnection();
                command.ExecuteNonQuery();
                manager.CloseConnection();
            }
            else if (pointer == "education")
            {
                int student_id = Convert.ToInt32(args[0]);
                string type = args[1];
                string university = args[2];
                DateTime graduation = Convert.ToDateTime(args[3]);

                DataBaseManager manager = new DataBaseManager();
                MySqlCommand command = new MySqlCommand("UPDATE education SET type = @type, university = @university, " +
                    "graduation = @graduation WHERE student_id = @student_id", manager.GetConnection);

                command.Parameters.Add("type", MySqlDbType.VarChar).Value = type;
                command.Parameters.Add("university", MySqlDbType.VarChar).Value = university;
                command.Parameters.Add("graduation", MySqlDbType.Date).Value = graduation;
                command.Parameters.Add("student_id", MySqlDbType.Int32).Value = student_id;

                manager.OpenConnection();
                command.ExecuteNonQuery();
                manager.CloseConnection();
            }
            else if (pointer == "passport")
            {
                Crypto crypto = new Crypto();
                string student_id = args[0];
                int series = Convert.ToInt32(args[1]);
                int number = Convert.ToInt32(args[2]);

                DataBaseManager manager = new DataBaseManager();
                MySqlCommand command = new MySqlCommand("UPDATE passport SET series = @series, number = @number " +
                    "WHERE student_id = @student_id", manager.GetConnection);

                command.Parameters.Add("@student_id", MySqlDbType.Int32).Value = Convert.ToInt32(student_id);
                command.Parameters.Add("@series", MySqlDbType.Int32).Value = crypto.EncryptSeries(series.ToString());
                command.Parameters.Add("@number", MySqlDbType.Int32).Value = crypto.EncryptNumber(number.ToString());
                
                manager.OpenConnection();
                command.ExecuteNonQuery();
                manager.CloseConnection();
            }
            else if (pointer == "contacts")
            {
                int student_id = Convert.ToInt32(args[0]);
                string mobilePhone = args[1];
                string email = args[2];

                DataBaseManager manager = new DataBaseManager();
                MySqlCommand command = new MySqlCommand("UPDATE contacts SET mobile_phone = @mobilePhone, email = @email " +
                    "WHERE student_id = @student_id", manager.GetConnection);

                command.Parameters.Add("@student_id", MySqlDbType.Int32).Value = student_id;
                command.Parameters.Add("@mobilePhone", MySqlDbType.VarChar).Value = mobilePhone;
                command.Parameters.Add("@email", MySqlDbType.VarChar).Value = email;

                manager.OpenConnection();
                command.ExecuteNonQuery();
                manager.CloseConnection();
            }
        }

        private void ViewAndEditForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        // Кнопка удаления выбранных строк данных из базы данных
        private void deleteButton_Click(object sender, EventArgs e)
        {
            DataBaseManager manager = new DataBaseManager();

            for (int i = 0; i < dataGridView.SelectedRows.Count; i++)
            {
                MySqlCommand command = new MySqlCommand(
                    "DELETE FROM education WHERE student_id = @student_id;" +
                    "DELETE FROM passport WHERE student_id = @student_id;" +
                    "DELETE FROM contacts WHERE student_id = @student_id;" +
                    "DELETE FROM student WHERE student_id = @student_id", manager.GetConnection);
                command.Parameters.Add("@student_id", MySqlDbType.Int32).Value = Convert.ToInt32(dataGridView.SelectedRows[i].Cells[1].Value);

                manager.OpenConnection();
                command.ExecuteNonQuery();
            }
            manager.CloseConnection();
            FillTable();
            MessageBox.Show("Данные успешно удалены.", "Внимание!");
        }

        private void круговаяДиаграммаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PieChartForm form = new PieChartForm();
            form.Show();
        }
    }
}
