﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Бельчич_15_1;

namespace УП_14
{
    public partial class PieChartForm : Form
    {
        public PieChartForm()
        {
            InitializeComponent();
        }

        Dictionary<string, int> educationTypeCount = new Dictionary<string, int>();
        private void PieChartForm_Shown(object sender, EventArgs e)
        {
            AddForm form = new AddForm();
            DataBaseManager manager = new DataBaseManager();
            int count = 0;
            manager.OpenConnection();
            foreach (var item in form.educationComboBox.Items)
            {
                if (educationTypeCount.Keys.Contains(item.ToString()) == false)
                {
                    MySqlCommand command = new MySqlCommand("SELECT COUNT(*) FROM education WHERE type = @type", manager.GetConnection);
                    command.Parameters.Add("@type", MySqlDbType.VarChar).Value = item.ToString();
                    count = Convert.ToInt32(command.ExecuteScalar());
                    if (count > 0)
                        educationTypeCount[item.ToString()] = count;
                }
            }
            manager.CloseConnection();
            double sum = 0;
            foreach (var value in educationTypeCount.Values) { sum += value; }
            foreach (var key in educationTypeCount.Keys)
            {
                educationTypePieChart.Series["Pie"].Points.AddXY($"{key} ({educationTypeCount[key]} чел. ({Math.Round(educationTypeCount[key]/sum * 100, 1)}%))", educationTypeCount[key]);
                //educationTypePieChart.Series["Pie"].Points.AddY(educationTypeCount[key]);
            }
            educationTypePieChart.Series["Pie"]["PieLabelStyle"] = "Disabled";
        }
    }
}
